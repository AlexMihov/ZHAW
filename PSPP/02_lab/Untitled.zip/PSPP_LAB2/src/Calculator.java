/**
 * User: Karl Rege
 */

interface ICalculator {
	int calc();
}

class Calculator {

	static Double stack[] = new Double[10];
	static int sp = 0;

	static void push(Double val) {
		stack[sp++] = val;
	}

	static Double pop() {
		return stack[--sp];
	}

	static void expr() throws Exception {
		term();
		while (Scanner.la == Token.PLUS || Scanner.la == Token.MINUS) {
			Scanner.scan();
			int op = Scanner.token.kind;
			term();
		}
	}

	static void term() throws Exception {
		factor();
		while (Scanner.la == Token.PLUS || Scanner.la == Token.MINUS || Scanner.la == Token.TIMES || Scanner.la == Token.SLASH) {
			Scanner.scan();
			int op = Scanner.token.kind;
			factor();
			if (op == Token.PLUS) {
				push(pop() + pop());
			} else if(op == Token.MINUS) {
				push(-pop() + pop());
			} else if(op == Token.TIMES){
				push(pop() * pop());
			} else if (op == Token.SLASH){
				push(1/pop() * pop());
			}
		}
	}

	static void factor() throws Exception {
		if (Scanner.la == Token.LBRACK) {
			Scanner.scan();
			expr();
			Scanner.check(Token.RBRACK);
		} else if (Scanner.la == Token.NUMBER) {
			Scanner.scan();
			push(Scanner.token.val);
		} else if (Scanner.la == Token.IDENT) {
			Scanner.scan();
			push(Scanner.token.val);
		}
	}

	public static void main(String[] args) throws Exception {
		Scanner.init("2*E");
		// System.out.print(Scanner.ch);

		Scanner.scan();

		expr();
		//System.out.println(Scanner.token.str);
		 System.out.println("result="+pop());

	}

}
